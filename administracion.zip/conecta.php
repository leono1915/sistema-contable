

<?php

    define("host","127.0.0.1");
  define("usuario","leono1915");
  define("db","aceros8dejulio");
  define("password","cmUZqgn8");
 $dbConexion= new mysqli(host,usuario,password,db);
 //print_r($dbConexion);
 

?>
<?php

session_start();
session_destroy();

?>
<!DOCTYPE HTML>
<!--
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>iniciar sesión</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	  
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		
	</head>
	<body >
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						
						
					</header>
				<!-- Main -->
				
					<article id="main">
						<header style="padding-top: 50px; padding-bottom: 50px;" >
							<h2>Aceros 8 de julio</h2>
							<p>iniciar sesión</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h4 style="text-align: center;">Identifíquese</h4>

									<form method="post" action="validar.php" >
										<div class="row uniform">
                                              <div class="4u 10u$(xsmall)" >
												
                                                </div>
                                                <div class="4u 10u$(xsmall)" >
												<input type="text" name="usuario" placeholder="usuario">
                                                </div>
                                             
                                                <div class="4u 10u$(xsmall)" >
											
                                                </div>
                                                <div class="4u 10u$(xsmall)" >
												
                                                </div>
                                                <div class="4u 10u$(xsmall)" >
                                              
                                                </div>
                                                <div class="4u 10u$(xsmall)" >
                                                
                                                </div>
                                                <div class="4u 10u$(xsmall)" >
												<input type="password" name=" password" placeholder="password">
												</div>
												<div class="6u 10u$(xsmall)" >
											
												</div>
												<div class="4u 10u$(xsmall)" >
												<input type="submit" value="Entrar">
												</div>
</div>
									</form>
									
								</section>
								<br> 
								<br>
								<br>
							</div>
						</section>
					</article>
					<section id="conte"></section>
				<!-- Footer -->
					<footer id="footer">
						<ul class="icons">
							
						</ul>
						<ul class="copyright">
							
					</footer>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
			<script src="lib/js/indee.js"></script>
    
	</body>
</html>